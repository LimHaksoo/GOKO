import BoardPage from '@/pages/BoardPage';

function App() {
  return <BoardPage />;
}

export default App;
