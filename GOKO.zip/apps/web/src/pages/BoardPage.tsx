import SplitView from '@/components/layout/SplitView';

function BoardPage() {
  return <SplitView />;
}

export default BoardPage;
