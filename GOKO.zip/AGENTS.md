## Review guidelines
- Security: secrets 하드코딩 금지, 입력 검증/인증/권한 누락 점검
- Tests: 핵심 유닛/스모크 테스트 누락이면 P1로 취급
- DX: 실행 방법/README 누락이면 P1
- Treat docs typos as P1
